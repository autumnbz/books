package com.jd.jes.client.demo;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;
import static org.elasticsearch.index.query.QueryBuilders.boolQuery;
import static org.elasticsearch.index.query.QueryBuilders.termQuery;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.count.CountResponse;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.IdsQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHitField;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.metrics.stats.StatsBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.elasticsearch.search.sort.SortOrder;

public class ClientTest {
	private static Client client = null;
	public static void main(String[] args) {
		
		try {
			//�ü�Ⱥ���֣���Ⱥ�ڵ��ַ����es client
			client = getClient("jiesi-1", "192.168.200.196", 9303);
			//����indexName:twitter, typeName:tweet������
			createIndex("twitter", "tweet");
			//��java�ַ���������twitter,typeΪtweet�д���document
			indexWithStr("twitter", "tweet");
			//��java map������twitter,typeΪtweet�д���document
			indexWithMap("twitter", "tweet");
			updateDoc("twitter", "tweet", "1");
			//��index:twitter, type:tweet����document id��ȡ
			indexWithBulk("twitter", "tweet");
			getWithId("twitter", "tweet", "4");
			scrollSearch("twitter", "tweet", "1", "2");
			//��ID��ѯdoc
			searchWithIds("twitter", "tweet", "postDate", "message", "1", "2");
			countWithQuery("twitter", "tweet", "user", "kimchy", "postDate", "message");
			//��index:twitter, type:tweet����term query��ѯ
			searchWithTermQuery("twitter", "tweet", "user", "101", "kimchy", "message");
			//sum one field value
			sumOneField("twitter", "tweet", "price");
			sumCountSearch("twitter", "tweet", "price", "tid", "message", "elasticsearch");
			//��index:twitter, type:tweet����term query��ѯ������ָ����field
			searchWithTermQueryAndRetureSpecifiedFields("twitter", "tweet", "user", "kimchy", "postDate", "message", "user", "message");
			//��index:twitter, type:tweet����booean query��ѯ
			searchWithBooleanQuery("twitter", "tweet", "user", "kimchy", "message", "Elasticsearch", "postDate", "message");
			//��index:twitter, type:tweet����range query��ѯ
			numericRangeSearch("twitter", "tweet", "price", 6.1, 6.3, "message");
			termRangeSearch("twitter", "tweet", "tid", "10000", "20000", "message");
			dateRangeSearch("twitter", "tweet", "endTime", "2015-08-20 12:27:11", "2015-08-29 14:00:00");
			dateRangeSearch2("twitter", "tweet", "endTime", "2015-08-21T08:35:13.890Z", "2015-08-30T14:00:00.000Z");
			rangeSearchWithOtherSearch("twitter", "tweet", "tid", "10000", "20000", "message");
			//��index:twitter, type:tweet����fuzzy search��ѯ
			fuzzySearch("twitter", "tweet", "message", "Elastic", "postDate", "message");
			//��index:twitter, type:tweet����wildcard��ѯ
			wildcardSearch("twitter", "tweet", "message", "El*stic", "postDate", "message");
			multiSearch();
			//��index:twitter, type:tweet��ɾ��idΪ1��doc
			deleteDocWithId("twitter", "tweet", "1");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (client != null) {
				client.close();
			}
		}
	}
	
	/**
	 * ��docId��ȡdocument
	 * @param indexName
	 * @param typeName
	 * @param docId
	 */
	private static void getWithId(String indexName, String typeName, String docId) {
		//get with id
		GetResponse gResponse = client.prepareGet(indexName, typeName, docId)
		        .execute()
		        .actionGet();
		System.out.println(gResponse.getIndex());
		System.out.println(gResponse.getType());
		System.out.println(gResponse.getVersion());
		System.out.println(gResponse.isExists());
		Map<String, Object> results = gResponse.getSource();
		if(results != null) {
			for(String key : results.keySet()) {
				Object field = results.get(key);
				System.out.println(key);
				System.out.println(field);
			}
		}
	}

	private static void multiSearch() {
		// TODO Auto-generated method stub
		
	}

	private static void indexWithBulk(String index, String type) {
				//ָ���������ƣ�type���ƺ�documentId(documentId��ѡ����������ϵͳ�Զ�����)����document
				IndexRequest ir1 = new IndexRequest();
				String source1 = "{" +
				        "\"user\":\"kimchy\"," +
				        "\"price\":\"6.3\"," +
				        "\"tid\":\"20001\"," +
				        "\"message\":\"Elasticsearch\"" +
				    "}";
				ir1.index(index).type(type).id("100").source(source1);
				IndexRequest ir2 = new IndexRequest();
				String source2 = "{" +
				        "\"user\":\"kimchy2\"," +
				        "\"price\":\"7.3\"," +
				        "\"tid\":\"20002\"," +
				        "\"message\":\"Elasticsearch\"" +
				    "}";
				ir2.index(index).type(type).id("102").source(source2);
				IndexRequest ir3 = new IndexRequest();
				String source3 = "{" +
				        "\"user\":\"kimchy3\"," +
				        "\"price\":\"8.3\"," +
				        "\"tid\":\"20003\"," +
				        "\"message\":\"Elasticsearch\"" +
				    "}";
				ir3.index(index).type(type).id("103").source(source3);
				BulkResponse response = client.prepareBulk().add(ir1).add(ir2).add(ir3).execute().actionGet();
				BulkItemResponse[] responses = response.getItems();
				if(responses != null && responses.length > 0) {
					for(BulkItemResponse r : responses) {
						String i = r.getIndex();
						String t = r.getType();
						System.out.println(i+","+t);
					}
				}
		
	}

	private static void sumCountSearch(String indexName, String typeName,
			String sumField, String countField, String searchField, String searchValue) {
		SumBuilder sb = AggregationBuilders.sum("sumPrice").field(sumField);
//		StatsBuilder vb = AggregationBuilders.stats("countTid").field(countField);
		TermQueryBuilder tb = QueryBuilders.termQuery(searchField, searchValue);
		//search result get source
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        .setQuery(tb)
//		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        .addAggregation(sb)
//		        .addAggregation(vb)
		        .execute()
		        .actionGet();
		Map<String, Aggregation> aggMap = sResponse.getAggregations().asMap();
		if(aggMap != null && aggMap.size() > 0) {
			for(String key : aggMap.keySet()) {
				if("sumPrice".equals(key)) {
					Sum s = (Sum)aggMap.get(key);
					System.out.println(key + "," + s.getValue());	
				}
				else if("countTid".equals(key)) {
					StatsBuilder c = (StatsBuilder)aggMap.get(key);
					System.out.println(key + "," + c.toString());
				}
				
			}
		}
	}

	private static void updateDoc(String indexName, String typeName, String id) throws IOException, InterruptedException, ExecutionException {
		UpdateRequest updateRequest = new UpdateRequest();
		updateRequest.index(indexName);
		updateRequest.type(typeName);
		updateRequest.id(id);
		updateRequest.doc(jsonBuilder()
		        .startObject()
		            .field("gender", "male")
		        .endObject());
		UpdateResponse resp = client.update(updateRequest).get();
		resp.getClass();
	}

	

	private static void scrollSearch(String indexName, String typeName, 
			String... ids) {
		IdsQueryBuilder qb = QueryBuilders.idsQuery().addIds(ids);
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        .setSearchType(SearchType.SCAN)
		        .setQuery(qb)
		        .setScroll(new TimeValue(100))
		        .setSize(50)
		        .execute()
		        .actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards+","+timeCost+","+sShards);
		
		while (true) {
			SearchHits hits = sResponse.getHits();
			SearchHit[] hitArray = hits.getHits();
			for(int i = 0; i < hitArray.length; i++) {
				SearchHit hit = hitArray[i];
				Map<String, Object> fields = hit.getSource();
				for(String key : fields.keySet()) {
					System.out.println(key);
					System.out.println(fields.get(key));
				}
			}
			sResponse = client.prepareSearchScroll(sResponse.getScrollId()).setScroll(new TimeValue(100)).execute().actionGet();
		    //Break condition: No hits are returned
		    if (sResponse.getHits().getHits().length == 0) {
		        break;
		    }
		}
	}

	private static void deleteDocuments(String string, String string2) {
		SearchResponse sResponse = client.prepareSearch(string)
		        .setTypes(string2)
		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        .setQuery(QueryBuilders.matchAllQuery())
		        .setFrom(0).setSize(60)
		        .execute()
		        .actionGet();
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		List<String> ids = new ArrayList<String>(hitArray.length);
		for(int i = 0; i < count; i++) {
			System.out.println("==================================");
			SearchHit hit = hitArray[i];
			ids.add(hit.getId());
			
		}
		for(String id : ids) {
			DeleteResponse response = client.prepareDelete(string, string2, id)
			        .execute()
			        .actionGet();
		}
		
	}

	private static void dateRangeSearch(String indexName, String typeName,
			String termName, String from, String to) {
		// ����range query
		//2015-08-20 12:27:11
				QueryBuilder qb = QueryBuilders.rangeQuery(termName).from(from).to(to);
				SearchResponse sResponse = client.prepareSearch(indexName)
						.setTypes(typeName)
						// ����search type
						// ����search type�ã�query_then_fetch
						// query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
						.setSearchType(SearchType.QUERY_THEN_FETCH)
						// ��ѯ��termName��termvalue
						.setQuery(qb)
						// ��������field
						.addSort(termName, SortOrder.DESC)
						// ���÷�ҳ
						.setFrom(0).setSize(60).execute().actionGet();
				int tShards = sResponse.getTotalShards();
				long timeCost = sResponse.getTookInMillis();
				int sShards = sResponse.getSuccessfulShards();
				System.out.println(tShards + "," + timeCost + "," + sShards);
				SearchHits hits = sResponse.getHits();
				long count = hits.getTotalHits();
				SearchHit[] hitArray = hits.getHits();
				for (int i = 0; i < count; i++) {
					SearchHit hit = hitArray[i];
					Map<String, Object> fields = hit.getSource();
					for (String key : fields.keySet()) {
						System.out.println(key);
						System.out.println(fields.get(key));
					}
				}
		
	}
	
	private static void dateRangeSearch2(String indexName, String typeName,
			String termName, String from, String to) {
		// ����range query
		//2015-08-20 12:27:11
//				DateTimeFormatter formatter = ISODateTimeFormat.basicDateTime();
//				LocalDate fromDateTime = formatter.parseLocalDate(from);
//				LocalDate toDateTime = formatter.parseLocalDate(to);
				QueryBuilder qb = QueryBuilders.rangeQuery(termName).from(from).to(to);
				SearchResponse sResponse = client.prepareSearch(indexName)
						.setTypes(typeName)
						// ����search type
						// ����search type�ã�query_then_fetch
						// query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
						.setSearchType(SearchType.QUERY_THEN_FETCH)
						// ��ѯ��termName��termvalue
						.setQuery(qb)
						// ��������field
						.addSort(termName, SortOrder.DESC)
						// ���÷�ҳ
						.setFrom(0).setSize(60).execute().actionGet();
				int tShards = sResponse.getTotalShards();
				long timeCost = sResponse.getTookInMillis();
				int sShards = sResponse.getSuccessfulShards();
				System.out.println(tShards + "," + timeCost + "," + sShards);
				SearchHits hits = sResponse.getHits();
				long count = hits.getTotalHits();
				SearchHit[] hitArray = hits.getHits();
				for (int i = 0; i < count; i++) {
					SearchHit hit = hitArray[i];
					Map<String, Object> fields = hit.getSource();
					for (String key : fields.keySet()) {
						System.out.println(key);
						System.out.println(fields.get(key));
					}
				}
		
	}

	private static void countWithQuery(String indexName, String typeName, String termName, String termValue, String sortField, String highlightField) {
		//search result get source
				CountResponse cResponse = client.prepareCount(indexName)
				        .setTypes(typeName)
				        .setQuery(QueryBuilders.termQuery(termName, termValue))
				        .execute()
				        .actionGet();
				int tShards = cResponse.getTotalShards();
				int sShards = cResponse.getSuccessfulShards();
				System.out.println(tShards+","+sShards);
				long count = cResponse.getCount();
					
	}

	private static void rangeSearchWithOtherSearch(String indexName, String typeName,
			String termName, String min, String max, String termQueryField) {
		// ����range query
				QueryBuilder qb = QueryBuilders.rangeQuery(termName).from(min).to(max);
				TermQueryBuilder tb = QueryBuilders.termQuery(termName, termQueryField);
				BoolQueryBuilder bq = boolQuery().must(qb).must(tb);
				SearchResponse sResponse = client.prepareSearch(indexName)
						.setTypes(typeName)
						// ����search type
						// ����search type�ã�query_then_fetch
						// query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
						.setSearchType(SearchType.QUERY_THEN_FETCH)
						// ��ѯ��termName��termvalue
						.setQuery(bq)
						// ��������field
						.addSort(termName, SortOrder.DESC)
						// ���÷�ҳ
						.setFrom(0).setSize(60).execute().actionGet();
				int tShards = sResponse.getTotalShards();
				long timeCost = sResponse.getTookInMillis();
				int sShards = sResponse.getSuccessfulShards();
				System.out.println(tShards + "," + timeCost + "," + sShards);
				SearchHits hits = sResponse.getHits();
				long count = hits.getTotalHits();
				SearchHit[] hitArray = hits.getHits();
				for (int i = 0; i < count; i++) {
					SearchHit hit = hitArray[i];
					Map<String, Object> fields = hit.getSource();
					for (String key : fields.keySet()) {
						System.out.println(key);
						System.out.println(fields.get(key));
					}
				}

		
	}

	private static void termRangeSearch(String indexName, String typeName,
			String termName, String min, String max, String highlightField) {

		// ����range query
		QueryBuilder qb = QueryBuilders.rangeQuery(termName).from(min).to(max);
		SearchResponse sResponse = client.prepareSearch(indexName)
				.setTypes(typeName)
				// ����search type
				// ����search type�ã�query_then_fetch
				// query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
				.setSearchType(SearchType.QUERY_THEN_FETCH)
				// ��ѯ��termName��termvalue
				.setQuery(qb)
				// ��������field
				.addSort(termName, SortOrder.DESC)
				//���ø���field
		        .addHighlightedField(highlightField)
				// ���÷�ҳ
				.setFrom(0).setSize(60).execute().actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards + "," + timeCost + "," + sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for (int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for (String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}

	
		
	}

	private static void sumOneField(String indexName, String typeName, String fieldName) {
		SumBuilder sb = AggregationBuilders.sum("sum").field(fieldName);
		//search result get source
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        .addAggregation(sb)
		        .execute()
		        .actionGet();
		Map<String, Aggregation> aggMap = sResponse.getAggregations().asMap();
		if(aggMap != null && aggMap.size() > 0) {
			for(String key : aggMap.keySet()) {
				Sum s = (Sum)aggMap.get(key);
				System.out.println(s.getValue());
			}
		}
	}

	private static void searchWithTermQueryAndRetureSpecifiedFields(String indexName, String typeName, String termName, 
			String termValue, String sortField, String highlightField,
			String... fields) {
		// search result get specified fields
		SearchRequestBuilder sb = client.prepareSearch(indexName)
				.setTypes(typeName)
				// ����search type
				// ����search type�ã�query_then_fetch
				// query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
				.setSearchType(SearchType.QUERY_THEN_FETCH)
				// ��ѯ��termName��termvalue
				.setQuery(QueryBuilders.termQuery(termName, termValue))
				// ��������field
				.addSort(sortField, SortOrder.DESC)
				// ���ø���field
				.addHighlightedField(highlightField)
				// ���÷�ҳ
				.setFrom(0).setSize(60);
		for (String field : fields) {
			sb.addField(field);
		}
		SearchResponse sResponse = sb.execute().actionGet();
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for (int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, SearchHitField> fm = hit.getFields();
			for (String key : fm.keySet()) {
				SearchHitField f = fm.get(key);
				System.out.println(f.getName());
				System.out.println(f.getValue());
			}
		}
	}

	private static void searchWithIds(String indexName, String typeName, String sortField, String highlightField, 
			String... ids) {
		IdsQueryBuilder qb = QueryBuilders.idsQuery().addIds(ids);
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        //����search type
		        //����search type�ã�query_then_fetch
		        //query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        //��ѯ��termName��termvalue
		        .setQuery(qb)
		        //��������field
		        .addSort(sortField, SortOrder.DESC)
		        //���ø���field
		        .addHighlightedField(highlightField)
		        //���÷�ҳ
		        .setFrom(0).setSize(60)
		        .execute()
		        .actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards+","+timeCost+","+sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for(int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for(String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}
		
	}

	/**
	 * ��index:indexName, type:typeName����ͨ�����ѯ
	 * @param indexName
	 * @param typeName
	 * @param termName
	 * @param termValue
	 * @param sortField
	 * @param highlightField
	 */
	private static void wildcardSearch(String indexName, String typeName, String termName, String termValue, String sortField, String highlightField) {
		QueryBuilder qb = QueryBuilders.wildcardQuery(termName, termValue);
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        //����search type
		        //����search type�ã�query_then_fetch
		        //query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        //��ѯ��termName��termvalue
		        .setQuery(qb)
		        //��������field
//		        .addSort(sortField, SortOrder.DESC)
		        //���ø���field
//		        .addHighlightedField(highlightField)
		        //���÷�ҳ
		        .setFrom(0).setSize(60)
		        .execute()
		        .actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards+","+timeCost+","+sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for(int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for(String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}
		
	}

	/**
	 * ��index:indexName, type:typeName����ģ����ѯ
	 * @param indexName
	 * @param typeName
	 * @param termName
	 * @param termValue
	 * @param sortField
	 * @param highlightField
	 */
	private static void fuzzySearch(String indexName, String typeName, String termName, String termValue, String sortField, String highlightField) {
		 QueryBuilder qb = QueryBuilders.fuzzyQuery(termName, termValue);
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        //����search type
		        //����search type�ã�query_then_fetch
		        //query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        //��ѯ��termName��termvalue
		        .setQuery(qb)
		        //��������field
		        .addSort(sortField, SortOrder.DESC)
		        //���ø���field
		        .addHighlightedField(highlightField)
		        //���÷�ҳ
		        .setFrom(0).setSize(60)
		        .execute()
		        .actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards+","+timeCost+","+sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for(int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for(String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}
		
	}



	/**
	 * ��index:indexName, type:typeName���������ѯ
	 * @param indexName
	 * @param typeName
	 * @param termName
	 * @param min
	 * @param max
	 * @param highlightField
	 */
	private static void numericRangeSearch(String indexName, String typeName,
			String termName, double min, double max, String highlightField) {
		// ����range query
		QueryBuilder qb = QueryBuilders.rangeQuery(termName).from(min).to(max);
		SearchResponse sResponse = client.prepareSearch(indexName)
				.setTypes(typeName)
				// ����search type
				// ����search type�ã�query_then_fetch
				// query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
				.setSearchType(SearchType.QUERY_THEN_FETCH)
				// ��ѯ��termName��termvalue
				.setQuery(qb)
				// ��������field
				.addSort(termName, SortOrder.DESC)
				//���ø���field
		        .addHighlightedField(highlightField)
				// ���÷�ҳ
				.setFrom(0).setSize(60).execute().actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards + "," + timeCost + "," + sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for (int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for (String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}

	}


	/**
	 * ������indexName, typeΪtypeName�в�������term��term1(termName1, termValue1)��term2(termName2, termValue2)
	 * @param indexName
	 * @param typeName
	 * @param termName1
	 * @param termValue1
	 * @param termName2
	 * @param termValue2
	 * @param sortField
	 * @param highlightField
	 */
	private static void searchWithBooleanQuery(String indexName, String typeName, String termName1, String termValue1, 
			 String termName2, String termValue2, String sortField, String highlightField) {
		//����boolean query
		BoolQueryBuilder bq = boolQuery()
		.must(termQuery(termName1, termValue1))    
		.must(termQuery(termName2, termValue2));    
		//.mustNot(termQuery("content", "test2")) 
		//.should(termQuery("content", "test3"));
		System.out.println(bq.toString());
		
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        //����search type
		        //����search type�ã�query_then_fetch
		        //query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        //��ѯ��termName��termvalue
		        .setQuery(bq)
		        //��������field
		        .addSort(sortField, SortOrder.DESC)
		        //���ø���field
		        .addHighlightedField(highlightField)
		        //���÷�ҳ
		        .setFrom(0).setSize(60)
		        .execute()
		        .actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
		System.out.println(tShards+","+timeCost+","+sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for(int i = 0; i < count; i++) {
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for(String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}
	}

	
	/**
	 * ������indexName, typeΪtypeName�в���term(termName, termValue)
	 * @param indexName
	 * @param typeName
	 * @param termName
	 * @param termValue
	 * @param sortField
	 * @param highlightField
	 */
	private static void searchWithTermQuery(String indexName, String typeName, String termName, String termValue, String sortField, String highlightField) {
		//search result get source
		
		SearchResponse sResponse = client.prepareSearch(indexName)
		        .setTypes(typeName)
		        //����search type
		        //����search type�ã�query_then_fetch
		        //query_then_fetch���Ȳ鵽��ؽṹ��Ȼ��ۺϲ�ͬnode�ϵĽ��������
		        .setSearchType(SearchType.QUERY_THEN_FETCH)
		        //��ѯ��termName��termvalue
		        .setQuery(QueryBuilders.termQuery(termName, termValue))
		        //��������field
//		        .addSort(sortField, SortOrder.DESC)
		        //���ø���field
//		        .addHighlightedField(highlightField)
		        //���÷�ҳ
		        .setFrom(0).setSize(60)
		        .execute()
		        .actionGet();
		int tShards = sResponse.getTotalShards();
		long timeCost = sResponse.getTookInMillis();
		int sShards = sResponse.getSuccessfulShards();
//		System.out.println(tShards+","+timeCost+","+sShards);
		SearchHits hits = sResponse.getHits();
		long count = hits.getTotalHits();
		SearchHit[] hitArray = hits.getHits();
		for(int i = 0; i < count; i++) {
			System.out.println("==================================");
			SearchHit hit = hitArray[i];
			Map<String, Object> fields = hit.getSource();
			for(String key : fields.keySet()) {
				System.out.println(key);
				System.out.println(fields.get(key));
			}
		}
	}


	/**
	 * ��java��map����document
	 */
	private static void indexWithMap(String indexName, String typeName) {
		Map<String, Object> json = new HashMap<String, Object>();
		//����document��field
		json.put("user","kimchy2");
		json.put("postDate",new Date());
		json.put("price",6.4);
		json.put("message","Elasticsearch");
		json.put("tid","10002");
//		json.put("location","-77.03653, 38.897676");
		json.put("endTime","2015-08-25 09:00:00");
		//ָ���������ƣ�type���ƺ�documentId(documentId��ѡ����������ϵͳ�Զ�����)����document
		IndexResponse response = client.prepareIndex(indexName, typeName, "2")
		        .setSource(json)
		        .execute()
		        .actionGet();
		//response�з����������ƣ�type���ƣ�doc��Id�Ͱ汾��Ϣ
		String index = response.getIndex();
		String type = response.getType();
		String id = response.getId();
		long version = response.getVersion();
		boolean created = response.isCreated();
		System.out.println(index+","+type+","+id+","+version+","+created);
	}

	/**
	 * ��java�ַ�������document
	 */
	private static void indexWithStr(String indexName, String typeName) {
		//�ֹ�����json�ַ���
		//��document����user, postData��message����field
		String json = "{" +
		        "\"user\":\"kimchy\"," +
		        "\"postDate\":\"2013-01-30\"," +
		        "\"price\":\"6.3\"," +
		        "\"tid\":\"10001\"," +
//		        "\"location\":\"-77.03653, 38.897676\"," +
		        "\"endTime\":\"2015-08-19 09:00:00\"," +
		        "\"message\":\"Elasticsearch\"" +
		    "}";
		//ָ���������ƣ�type���ƺ�documentId(documentId��ѡ����������ϵͳ�Զ�����)����document
		IndexResponse response = client.prepareIndex(indexName, typeName, "1")
		        .setSource(json)
		        .execute()
		        .actionGet();
		//response�з����������ƣ�type���ƣ�doc��Id�Ͱ汾��Ϣ
		String index = response.getIndex();
		String type = response.getType();
		String id = response.getId();
		long version = response.getVersion();
		boolean created = response.isCreated();
		System.out.println(index+","+type+","+id+","+version+","+created);
	}
	
	/**
	 * ����es client
	 * clusterName:��Ⱥ����
	 * nodeIp:��Ⱥ�нڵ��ip��ַ
	 * nodePort:�ڵ�Ķ˿�
	 * @return
	 * @throws UnknownHostException 
	 */
	public static Client getClient(String clusterName, String nodeIp, int nodePort) throws UnknownHostException {
		//���ü�Ⱥ������
		Settings settings = Settings.settingsBuilder()
		        .put("cluster.name", clusterName)
		        .put("client.transport.sniff", false)
//		        .put("number_of_shards", 1)
//		        .put("number_of_replicas", 0)
		        .build();
		
		//������Ⱥclient�����Ӽ�Ⱥ�ڵ��ַ
		Client client =TransportClient.builder().settings(settings).build()
//				.addTransportAddress(new InetSocketTransportAddress("192.168.200.195", 9370))
//				.addTransportAddress(new InetSocketTransportAddress("192.168.200.196", 9370))
//				.addTransportAddress(new InetSocketTransportAddress("192.168.200.197", 9370))
//				.addTransportAddress(new InetSocketTransportAddress("192.168.200.198", 9370))
				.addTransportAddress(
						new InetSocketTransportAddress(InetAddress.getByName(nodeIp),
								nodePort));
				
		return client;
	}


	private static void deleteDocWithId(String indexName, String typeName, String docId) {
		DeleteResponse dResponse = client.prepareDelete(indexName, typeName, docId)
		        .execute()
		        .actionGet();
		String index = dResponse.getIndex();
		String type = dResponse.getType();
		String id = dResponse.getId();
		long version = dResponse.getVersion();
		System.out.println(index+","+type+","+id+","+version);
	}
	
	/**
	 * ��������
	 * ע�⣺������������֪ͨes��Ⱥ��ownerȥ����index
	 * @param client
	 * @param indexName
	 * @param documentType
	 * @throws IOException
	 */
	private static void createIndex(String indexName, String documentType) throws IOException {
		final IndicesExistsResponse iRes = client.admin().indices().prepareExists(indexName).execute().actionGet();
        if (iRes.isExists()) {
            client.admin().indices().prepareDelete(indexName).execute().actionGet();
        }
        client.admin().indices().prepareCreate(indexName).setSettings(Settings.settingsBuilder().put("number_of_shards", 1).put("number_of_replicas", "0")).execute().actionGet();
        XContentBuilder mapping = jsonBuilder()
                .startObject()
                     .startObject(documentType)
//                     .startObject("_routing").field("path","tid").field("required", "true").endObject()
                      .startObject("_source").field("enabled", "true").endObject()
                      .startObject("_all").field("enabled", "false").endObject()
                          .startObject("properties")
                              .startObject("user")
                              	  .field("store", true)
                                  .field("type", "string")
                                  .field("index", "not_analyzed")
                               .endObject()
                               .startObject("message")
                               	  .field("store", true)
                                  .field("type","string")
                                  .field("index", "analyzed")
                                  .field("analyzer", "standard")
                               .endObject()
                               .startObject("price")
                               	  .field("store", true)
                               	  .field("type", "float")
                               .endObject()
                               .startObject("nv1")
                               	  .field("store", true)
                               	  .field("type", "integer")
                               	  .field("index", "no")
                               	  .field("null_value", 0)
                               .endObject()
                               .startObject("nv2")
                               	  .field("store", true)
                               	  .field("type", "integer")
                               	  .field("index", "not_analyzed")
                               	  .field("null_value", 10)
                               .endObject()
                               .startObject("tid")
                              	  .field("store", true)
                                  .field("type", "string")
                                  .field("index", "not_analyzed")
                               .endObject()
//                               .startObject("location")
//                              	  .field("store", true)
//                                  .field("type", "geo_point")
//                                  .field("lat_lon", true)
//                                  .field("geohash", true)
//                                  .field("geohash_prefix", true)
//                                  .field("geohash_precision", 7)
//                               .endObject()
//                               .startObject("shape")
//                              	  .field("store", true)
//                                  .field("type", "geo_shape")
//                                  .field("geohash", true)
//                                  .field("geohash_prefix", false)
//                                  .field("geohash_precision", 7)
//                               .endObject()
                               .startObject("endTime")
                                  .field("type", "date")
                                  .field("store", true)
                                  .field("index", "not_analyzed")
                                  //2015-08-21T08:35:13.890Z
                                  .field("format", "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd'T'HH:mm:ss.SSSZ")
                               .endObject()
                               .startObject("date")
                                  .field("type", "date")
//                                  .field("store", true)
//                                  .field("index", "not_analyzed")
                                  //2015-08-21T08:35:13.890Z
//                                  .field("format", "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd'T'HH:mm:ss.SSSZ")
                               .endObject()
                          .endObject()
                      .endObject()
                   .endObject();
        client.admin().indices()
                .preparePutMapping(indexName)
                .setType(documentType)
                .setSource(mapping)
                .execute().actionGet();
	}
	

}
