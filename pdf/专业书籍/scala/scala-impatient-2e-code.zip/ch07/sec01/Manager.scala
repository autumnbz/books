package com {
  package horstmann {
    package impatient {
      class Manager(name: String) {
        def description = "A manager with name " + name
      }      
    }
  }
}
