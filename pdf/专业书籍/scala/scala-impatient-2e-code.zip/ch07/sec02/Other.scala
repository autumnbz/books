package com {
  package horstmann {
    package collection {
      // ...
    }
  }
}
