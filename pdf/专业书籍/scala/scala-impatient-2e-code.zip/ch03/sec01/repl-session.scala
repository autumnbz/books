// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

val nums = new Array[Int](10)

val a = new Array[String](10)

val s = Array("Hello", "World")
s(0) = "Goodbye"
s
