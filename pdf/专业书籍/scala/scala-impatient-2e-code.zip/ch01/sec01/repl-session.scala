// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

8 * 5 + 2

0.5 * res0

"Hello, " + res0

res2.toUpperCase

