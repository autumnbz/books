// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

import scala.math._

sqrt(2)
pow(2, 4)
min(3, Pi)

"Hello".distinct

BigInt.probablePrime(100, scala.util.Random)
