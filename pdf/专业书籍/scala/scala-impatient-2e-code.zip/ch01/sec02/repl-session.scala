// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

val answer = 8 * 5 + 2

0.5 * answer

val greeting: String = null

answer = 0 // This will give an error

var counter = 0
counter = 1 // Ok, can change a var

var i, j = 0
var greeting2, message: String = null

