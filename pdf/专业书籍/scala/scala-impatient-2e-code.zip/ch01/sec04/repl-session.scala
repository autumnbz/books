// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

"Hello" intersect "World" // Can omit . and () for binary method

val counter = 0
counter+=1 // Increments counter—Scala has no ++

val x: BigInt = 1234567890
x * x * x

