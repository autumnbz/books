// These are meant to be typed into the REPL. You can also run
// scala -Xnojline < repl-session.scala to run them all at once.

"Hello"(4)

"Hello".apply(4)

BigInt("1234567890")

BigInt.apply("1234567890")

BigInt("1234567890") * BigInt("112358111321")

